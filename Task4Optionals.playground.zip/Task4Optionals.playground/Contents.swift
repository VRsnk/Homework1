//: Playground - noun: a place where people can play

import UIKit

//1
var integerNumber: Int?

//2
var decimalNumber :Float?

//3


//3


//4


//5


//6

