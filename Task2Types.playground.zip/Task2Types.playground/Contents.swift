import UIKit
//1
//???

//2
//???

//3
let hexadecimalInt = 0x80

//4
let min16Value = UInt16.max

//5
let max64Value = UInt64.max

//6
//???

//7
var myChar: Character = "a"

//8
var myString = "Hello World!"

//9
var boolValue: Bool = true

//10
let x = (12, "twelve")
x.1
