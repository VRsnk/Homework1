//
//  main.swift
//  HelloWorld2
//
//  Created by vr on 4/18/18.
//  Copyright © 2018 vr. All rights reserved.
//

import Foundation

print("Hello, World!")

