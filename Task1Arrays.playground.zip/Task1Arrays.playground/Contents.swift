import UIKit

//1
let fibArray: [Int] = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]

//2
let revArray: [Int] = fibArray.reversed()

//3
var snglArray = [Int]()
snglArray += 1...100

//4
snglArray.count

//5
snglArray[9]

//6
snglArray[9...14]

//7
let rptArray = Array(repeating: snglArray[9], count: 10)

//8
var oddArray = [Int](0...10)

//9
oddArray.append(11)

//10
oddArray += [15,17,19]

//11
oddArray.insert(13, at: 12 )


//12
oddArray.removeSubrange(4...8)

//13
oddArray.removeFirst()
let firstremoved = oddArray.removeFirst()
print(firstremoved)

//14
oddArray.replaceSubrange(1...8, with: [2, 3, 4])


//15
if let valueToRemove = oddArray.index(of: 3) {
    oddArray.remove(at: valueToRemove)
}

//16
let hasValue3 = oddArray.contains(3)

//17
var convertToString = oddArray.map(String.init)




