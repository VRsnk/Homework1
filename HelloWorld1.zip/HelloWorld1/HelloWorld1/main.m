//
//  main.m
//  HelloWorld1
//
//  Created by vr on 4/18/18.
//  Copyright © 2018 vr. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        NSLog(@"Hello, World!");
    }
    return 0;
}
